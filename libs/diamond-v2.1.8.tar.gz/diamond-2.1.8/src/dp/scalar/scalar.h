#pragma once
void smith_waterman(Sequence q, Sequence s, Hsp& out);